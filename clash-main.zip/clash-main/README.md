OpenClash 完美配置
请参看油管视频配置，本项目为配置文件。
https://www.youtube.com/watch?v=S2l_0g4EOHk&t=2s
